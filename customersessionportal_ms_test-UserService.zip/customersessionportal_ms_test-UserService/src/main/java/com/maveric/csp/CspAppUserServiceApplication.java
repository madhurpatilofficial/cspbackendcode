package com.maveric.csp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaClient
public class CspAppUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CspAppUserServiceApplication.class, args);
	}

}
