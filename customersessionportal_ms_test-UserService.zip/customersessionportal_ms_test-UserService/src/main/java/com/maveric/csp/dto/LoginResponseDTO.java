package com.maveric.csp.dto;

public record LoginResponseDTO(String jwt, String loggedInUser) {
}
