package com.maveric.csp.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.csp.entities.Customer;
import com.maveric.csp.entities.CustomerGroup;
import com.maveric.csp.entities.CustomerGroupReference;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.exceptions.DuplicateNameException;
import com.maveric.csp.repositories.CustomerGroupReferenceRepository;
import com.maveric.csp.repositories.CustomerGroupRepository;
import com.maveric.csp.repositories.CustomerRepository;

import jakarta.transaction.Transactional;

@Service
public class CustomerGroupServiceImpl implements CustomerGroupService {

	@Autowired
	CustomerGroupRepository customerGroupRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerGroupReferenceRepository referenceRepository;

	/*
	 * *************************************** createCustomerGroup
	 * *************************************************
	 */
	@Override
	public CustomerGroup createCustomerGroup(CustomerGroup group) throws DuplicateNameException {

		Optional<CustomerGroup> dbGroup = customerGroupRepository.findByGroupName(group.getGroupName());

		System.out.println(dbGroup);

		if (dbGroup.isPresent()) {

			throw new DuplicateNameException("Group name is Duplicate");

		} else {
			CustomerGroup savedGroup = customerGroupRepository.save(group);
			List<Customer> customers = group.getCustomers();
			if (customers != null) {
				for (Customer customer : customers) {

					CustomerGroupReference reference = new CustomerGroupReference();
					Optional<Customer> foundCustomer = customerRepository.findById(customer.getCustomerId());

					if (foundCustomer.isPresent()) {

						Customer dbCustomer = foundCustomer.get();
						reference.setCustomerId(dbCustomer.getCustomerId());
					}
					reference.setGroupId(savedGroup.getGroupId());

					referenceRepository.save(reference);
				}
			}
			return savedGroup;
		}
	}

	/*
	 * *************************************** getCustomerByGroupName
	 * *************************************************
	 */

	@Override
	public List<CustomerGroup> getCustomerByGroupName(String groupName) {

		CustomerGroup customerGroup = new CustomerGroup();

		List<CustomerGroup> customerGroups = new ArrayList<>();
		List<Customer> customers = new ArrayList<>();

		Optional<CustomerGroup> foundGroup = customerGroupRepository.findByGroupName(groupName);

		if (foundGroup.isPresent()) {

			CustomerGroup group = foundGroup.get();

			List<CustomerGroupReference> reference = referenceRepository.findByGroupId(group.getGroupId());

			for (CustomerGroupReference cref : reference) {
				Optional<Customer> customer = customerRepository.findById(cref.getCustomerId());

				if (customer.isPresent()) {
					Customer cust = customer.get();
					customers.add(cust);
				}
			}

			customerGroup.setGroupName(groupName);
			customerGroup.setCustomers(customers);
			customerGroup.setGroupId(group.getGroupId());

			customerGroups.add(customerGroup);

		}

		return customerGroups;
	}

	/*
	 * *************************************** deleteCustomerGroup
	 * *************************************************
	 */

	@Override
	public String deleteCustomerGroup(int groupId) throws AllExceptions {

		Optional<CustomerGroup> foundGroup = customerGroupRepository.findById(groupId);

		if (foundGroup.isPresent()) {
			customerGroupRepository.deleteById(groupId);

			List<CustomerGroupReference> groupReferences = referenceRepository.findByGroupId(groupId);
			referenceRepository.deleteAll(groupReferences);

			return "Success";
		} else {
			throw new AllExceptions("CustomerGroup is not Found");
		}
	}

	/*
	 * *************************************** getAllCustomerGroup
	 * *************************************************
	 */

	@Override
	public List<CustomerGroup> getAllCustomerGroup() {

		List<CustomerGroup> list = customerGroupRepository.findAll();

		return list;
	}

	

	@Transactional
	public CustomerGroup updateCustomerGroup(CustomerGroup group) throws DuplicateNameException, AllExceptions {
		Optional<CustomerGroup> dbGroup = customerGroupRepository.findById(group.getGroupId());

		List<CustomerGroup> dbGroupList = customerGroupRepository.findAll();

		boolean flag = dbGroupList.stream().anyMatch(t -> t.getGroupName().equals(group.getGroupName()));
		if (dbGroup.isEmpty()) {
			throw new AllExceptions("Group not found with ID: " + group.getGroupId());
		}

		CustomerGroup existingGroup = dbGroup.get();

		if (flag) {

			throw new DuplicateNameException("Group name already exists");
		} else {
			existingGroup
					.setGroupName(group.getGroupName() == null ? existingGroup.getGroupName() : group.getGroupName());
		}
		CustomerGroup savedGroup = customerGroupRepository.save(existingGroup);

		referenceRepository.deleteByGroupId(savedGroup.getGroupId());

		List<Customer> updatedCustomers = group.getCustomers();
		if (updatedCustomers != null) {
			for (Customer customer : updatedCustomers) {
				Optional<Customer> foundCustomer = customerRepository.findById(customer.getCustomerId());

				if (foundCustomer.isPresent()) {
					Customer dbCustomer = foundCustomer.get();

					CustomerGroupReference reference = new CustomerGroupReference();
					reference.setCustomerId(dbCustomer.getCustomerId());
					reference.setGroupId(savedGroup.getGroupId());
					referenceRepository.save(reference);
				}
			}
		}
		return savedGroup;
	}
//	public List<Map<String, Object>> getSessionByGroupName(String groupName) {
//        List<Object[]> sessions = SessionRepository.findByCustomerGroupName(groupName);
//        List<Map<String, Object>> sessionList = new ArrayList<>();
// 
//        for (Object[] session : sessions) {
//            Map<String, Object> sessionMap = new HashMap<>();
//            sessionMap.put("customerId", session[0]);
//            sessionMap.put("customerName", session[1]);
//            sessionMap.put("sessionId", session[2]);
//            sessionMap.put("modifiedBy", session[3]);
//            sessionMap.put("modifiedOn", session[4]);
//           // sessionMap.put("sessionId", session[5]);
//            sessionMap.put("followupOn", session[6]);
//            sessionMap.put("potentialLead", session[7]);
//            sessionMap.put("createdBy", session[8]);
//            sessionMap.put("createdOn", session[9]);
//            // Add other session attributes in the same format
//            sessionMap.put("isActive", session[10]);
//            sessionMap.put("priorityLevel", session[11]);
//            sessionMap.put("sessionName", session[12]);
//            sessionList.add(sessionMap);
//        }
// 
//        return sessionList;
//    }

}