package com.maveric.csp.entities;

public enum WealthMode {
	
	CREATION,PRESERVATION,COMBO;

}
