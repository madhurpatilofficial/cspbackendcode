package com.maveric.csp.exceptions;

public class AllExceptions extends Exception {

	public AllExceptions(String msg) {

		super(msg);
	}

}
