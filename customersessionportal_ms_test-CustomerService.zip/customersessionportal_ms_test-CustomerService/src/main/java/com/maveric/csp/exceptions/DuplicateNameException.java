package com.maveric.csp.exceptions;

public class DuplicateNameException  extends Exception  {
	
	public DuplicateNameException(String msg) {

		super(msg);
	}

}
