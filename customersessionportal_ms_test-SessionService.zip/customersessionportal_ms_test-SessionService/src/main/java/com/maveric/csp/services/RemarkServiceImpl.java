package com.maveric.csp.services;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.csp.conversion.AppConversions;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.repositories.RemarkRepository;

@Service
public class RemarkServiceImpl implements RemarkService {

	private static final Logger log = LoggerFactory.getLogger(RemarkServiceImpl.class);

	@Autowired
	RemarkRepository remarkRepository;

	@Override
	public Remark addRemark(Remark remark) throws AllExceptions {
		log.info("RemarkServiceImpl : addRemark() : Call Started");
		LocalDateTime currentDate = LocalDateTime.now();
		String formatedDate = AppConversions.convertDateToString(currentDate);
		remark.setCreatedDate(formatedDate);
		
		Remark addedRemark = remarkRepository.save(remark);
		
		if (addedRemark != null) {
			log.info("RemarkServiceImpl : addRemark() : Call Ended");
			return addedRemark;
		} else {
			throw new AllExceptions("Somthing went wrong while adding remark");
		}
	}

}
