package com.maveric.csp.dtos;

public enum WealthMode {
	
	CREATION,PRESERVATION,COMBO;

}
