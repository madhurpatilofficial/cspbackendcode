package com.maveric.csp.exceptions;
public class SessionNotFoundException extends Exception {

    public SessionNotFoundException(String message) {
        super(message);
    }
}