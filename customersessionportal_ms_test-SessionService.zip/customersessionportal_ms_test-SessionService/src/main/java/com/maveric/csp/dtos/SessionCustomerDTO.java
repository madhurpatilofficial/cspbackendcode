package com.maveric.csp.dtos;

import java.util.List;

import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;

import lombok.Data;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

@Data
@NoArgsConstructor
public class SessionCustomerDTO {

	private Session session;
	
	private CustomerDTO customerDetails;
}
