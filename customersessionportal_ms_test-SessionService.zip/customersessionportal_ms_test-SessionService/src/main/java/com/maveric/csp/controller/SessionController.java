package com.maveric.csp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.csp.dtos.SessionCustomerDTO;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.services.SessionService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/session")
public class SessionController {
	
	private static final Logger log = LoggerFactory.getLogger(SessionController.class);
	
	@Autowired
	SessionService sessionService;
	
//**********************************Create Session*************************************************************	
		@Operation(summary = "API to Create Session")
		@PostMapping("/create")
		public ResponseEntity<Session> createSession(@Valid @RequestBody Session session,@RequestHeader(name = "LoggedInUser", required = false) String username) throws SessionSaveException {
			
		log.info("SessionController : createSession() : Call Started");
			
		Session savedSession = sessionService.createSession(session,username);

		log.info("SessionController : createSession() : Call Started");
		return new ResponseEntity<>(savedSession, HttpStatus.CREATED);
		
		}
		
		
// **********************************Make Session Archived*************************************************************	

		@Operation(summary = "API to make Session Archive")
		@PostMapping("/archive/{sessionId}")
		public ResponseEntity<Session> makeArchiveSession(@PathVariable("sessionId") int sessionId) throws ArchiveSessionException, SessionNotFoundException {
			log.info("SessionController : makeArchiveSession() : Call Started");
			
			Session archivedSession= sessionService.makeArchiveSession(sessionId);
			
			log.info("SessionController : makeArchiveSession() : Call Ended");
			return new ResponseEntity<>(archivedSession, HttpStatus.OK);
			
			

		}

// **********************************Updated Session Api*************************************************************	
		@Operation(summary = "API to update Session")
		@PutMapping("/update")
		public ResponseEntity<Session> updateSession(@RequestBody Session session,@RequestHeader(name = "LoggedInUser", required = false) String username) throws SessionNotFoundException {
			log.info("SessionController : updateSession() : Call Started");
			Session updatedSession = sessionService.updateSession(session, username);
			log.info("SessionController : updateSession() : Call Ended");
			return new ResponseEntity<>(updatedSession,HttpStatus.OK);
		}
// **********************************View session by sessionId***********************************************************	

		@Operation(summary = "API to view session by sessionId")
		@GetMapping("/{sessionId}")
		public ResponseEntity<Session> getSessionDetails(@PathVariable("sessionId") int sessionId) throws SessionNotFoundException {
			log.info("SessionController : getSessionDetails() : Call Started");
			Session sessionDetails = sessionService.getSessionDetails(sessionId);
			log.info("SessionController : getSessionDetails() : Call Ended");
			return new ResponseEntity<>(sessionDetails,HttpStatus.OK);
		}

// *******************************View Active Sessions on Dashboard*****************************************************

		@Operation(summary = "API to View Active Sessions on Dashboard")
		@GetMapping("/activeSessions")
		public ResponseEntity<List<Session>> getActiveSessions(@RequestHeader(name = "LoggedInUser", required = false) String username) throws SessionNotFoundException {
			log.info("SessionController : getActiveSessions() : Call Started");
			System.out.println("Username>>>>>>"+username);
			List<Session> sessionList= sessionService.getActiveSessions(username);
			log.info("SessionController : getActiveSessions() : Call Ended");
			return new ResponseEntity<>(sessionList,HttpStatus.OK);

		}

//*********************************View Archived session on dashboard******************************************************

		@Operation(summary = "API to view Archived session on dashboard")
		@GetMapping("/archivedsessions")
		public ResponseEntity<List<Session>> getArchiveSessions(@RequestHeader(name = "LoggedInUser", required = false) String username) throws SessionNotFoundException {
			log.info("SessionController : getArchiveSessions() : Call Started");
			List<Session> sessionList = sessionService.getArchivedSessions(username);
			log.info("SessionController : getArchiveSessions() : Call Ended");
			return new ResponseEntity<>(sessionList,HttpStatus.OK);
		}
				
/* *********************************View session by customerID************************************************************ */

		@Operation(summary = "API to view session by customerID")
		@GetMapping("/customerID/{customerID}")
		public ResponseEntity<List<Session>> getSessionDetails(@PathVariable("customerID") Long customerID) throws SessionNotFoundException {
		
			log.info("SessionController : getSessionDetails() : Call Started");
			List<Session> sessionDetails = sessionService.getSessionDetails(customerID);
			log.info("SessionController : getSessionDetails() : Call Ended");
			return new ResponseEntity<>(sessionDetails,HttpStatus.OK);

		}

/* **********************************Filter by potentialLead*********************************************************** */

		@Operation(summary = "API to Get Session by PotentialLead")
		@GetMapping("/potentialLead/{potentialLead}")
		public ResponseEntity<List<Session>> getSessionDetails(@PathVariable("potentialLead") PotentialLead potentialLead) throws SessionNotFoundException {

			log.info("SessionController : getSessionDetails() : Call Started");
			List<Session> sessionDetails = sessionService.getSessionDetails(potentialLead);
			log.info("SessionController : getSessionDetails() : Call Ended");
			return new ResponseEntity<>(sessionDetails,HttpStatus.OK);

		}

//**********************************Filter by priorityLevel************************************************************ */	

		@Operation(summary = "API to Get Session by priorityLevel")
		@GetMapping("/priorityLevel/{priorityLevel}")
		public ResponseEntity<List<Session>> getByPriorityLevel(@PathVariable("priorityLevel") PriorityLevel priorityLevel) throws SessionNotFoundException {
			log.info("SessionController : getSessionDetails() : Call Started");
			List<Session> sessionDetails = sessionService.getSessionDetails(priorityLevel);
			log.info("SessionController : getSessionDetails() : Call Ended");
			return new ResponseEntity<>(sessionDetails,HttpStatus.OK);		}


		
//********************************** Auto Archive************************************************************************
		@Operation(summary = "API to Auto Archive Session")
		@GetMapping("/auto-archive")
	    public ResponseEntity<String> autoArchiveSessions() {
			log.info("SessionController : autoArchiveSessions() : Call Started");
			sessionService.autoArchiveSessions();
			log.info("SessionController : autoArchiveSessions() : Call Ended");
            return new ResponseEntity<>("Sessions auto-archived successfully.", HttpStatus.OK);
		}
		
//**********************************filter By Dates***********************************************************************	
		@Operation(summary = "API to get sessions based on date criteria")
		@GetMapping("/sessions")
		public ResponseEntity<List<Session>> getSessions(
		        @RequestParam(name = "createdOn", required = false) String createdOn,
		        @RequestParam(name = "modifiedOn", required = false) String modifiedOn,
		        @RequestParam(name = "followupOn", required = false) String followupOn,
		        @RequestParam(name = "fromDate", required = false) String fromDate,
		        @RequestParam(name = "toDate", required = false) String toDate,
		        @RequestParam(name = "dateType", defaultValue = "") String dateType) {
	 
		    log.info("SessionController : getSessions() : Call Started");
	 
		    try {
		        List<Session> sessionList = null;
	 
		        if (!dateType.isEmpty()) {
		            sessionList = sessionService.getSessions(fromDate, toDate, dateType);
		        } else if (createdOn != null) {
		            sessionList = sessionService.getSessionByCreatedOn(createdOn);
		        } else if (modifiedOn != null) {
		            sessionList = sessionService.getSessionByModifiedOn(modifiedOn);
		        } else if (followupOn != null) {
		            sessionList = sessionService.getSessionByfollowUpOn(followupOn);
		        } else {
		            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		        }
	 
		        if (sessionList != null && !sessionList.isEmpty()) {
		            log.info("SessionController : getSessions() : Call Ended");
		            return ResponseEntity.ok(sessionList);
		        } else {
		            return ResponseEntity.notFound().build();
		        }
		    } catch (SessionNotFoundException e) {
		    	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		    } catch (Exception e) {
		    	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	    }
		}
		
		
//**********************************filter By Dates***********************************************************************	
	
		@Operation(summary = "API to get session by Group Name")
		@GetMapping("/groupName/{groupName}")
		public ResponseEntity<List<Session>> getBygroupName(@PathVariable("groupName") String groupName) {
			log.info("SessionController : getBygroupName() : Call Started");
			List<Session> sessionList = sessionService.getBygroupName(groupName);

			if (sessionList != null) {
				log.info("SessionController : getBygroupName() : Call Ended");
				return new ResponseEntity<>(sessionList, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}

		}

}
