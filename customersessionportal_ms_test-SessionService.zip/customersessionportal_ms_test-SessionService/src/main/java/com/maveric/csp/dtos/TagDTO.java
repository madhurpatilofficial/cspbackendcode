package com.maveric.csp.dtos;

public class TagDTO {

}
