package com.maveric.csp.services;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.repositories.RemarkRepository;
import com.maveric.csp.repositories.SessionRepository;
import com.maveric.csp.repositories.TagRepository;

@Service
public class TagServiceImpl implements TagService {

	private static final Logger log = LoggerFactory.getLogger(TagServiceImpl.class);

	@Autowired
	TagRepository tagRepository;

	@Autowired
	SessionRepository sessionRepository;

	@Autowired
	RemarkRepository remarkRepository;
	
	@Autowired 
	WebClient webClient;

	@Override
	public Tag addRemark(Tag tag) {

		Tag savedTag = tagRepository.save(tag);

		if (savedTag != null) {
			return savedTag;
		}
		return savedTag;
	}

	@Override
	public List<Session> getSessionByTagName(String tagName) {

		List<Tag> tagList = tagRepository.findByTagName(tagName);
		List<Session> sessionList = new ArrayList<>();

		for (Tag tag : tagList) {
			Session session = sessionRepository.findById(tag.getSessionId()).get();
			List<Tag> tags = tagRepository.findBySessionId(session.getSessionId());
			List<Remark> remarks = remarkRepository.findBySessionId(session.getSessionId());
			CustomerDTO customer = webClient.get()
					.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
					.retrieve()
					.bodyToMono(CustomerDTO.class).block();
			session.setCustomerDetails(customer);
			session.setTags(tags);
			session.setRemarks(remarks);
			sessionList.add(session);
		}
		return sessionList;
	}

	@Override
	public List<String> getAllTags() {
		List<String> tags = tagRepository.findAllTags();

		if (tags.isEmpty()) {

			log.error("list is empty");
		}
		
		return tags;

	}



}
