package com.maveric.csp.dtos;

import java.util.List;

import jakarta.persistence.Transient;

public class CustomerGroupDTO {
	
	
	private int groupId;
	
	private String groupName;
	
	@Transient
	private List<CustomerDTO> customers;

}
