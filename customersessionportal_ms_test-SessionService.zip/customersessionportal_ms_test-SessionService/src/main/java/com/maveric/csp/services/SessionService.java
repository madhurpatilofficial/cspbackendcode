package com.maveric.csp.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.csp.dtos.SessionCustomerDTO;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;

@Service
public interface SessionService {

	Session createSession(Session sessionRequest, String username) throws SessionSaveException;
	
	Session updateSession(Session session, String username)throws SessionNotFoundException;
	
	Session makeArchiveSession(int sessionId) throws ArchiveSessionException, SessionNotFoundException;

	List<Session> getActiveSessions(String username)throws SessionNotFoundException;

	List<Session> getArchivedSessions(String username)throws SessionNotFoundException;

	Session getSessionDetails(int sessionId)throws SessionNotFoundException;

	List<Session> getSessionDetails(long customerID)throws SessionNotFoundException;

	List<Session> getSessionDetails(PotentialLead potentialLead)throws SessionNotFoundException;
	
	List<Session> getSessionDetails(PriorityLevel priorityLevel)throws SessionNotFoundException;
	
	List<Session> getSessionByCreatedOn(String createdOn)throws SessionNotFoundException;
	
	List<Session> getSessionByCreatedOn(String fromDate, String toDate)throws SessionNotFoundException;

	List<Session> getSessionByModifiedOn(String fromDate, String toDate)throws SessionNotFoundException;

	List<Session> getSessionByModifiedOn(String modifiedOn)throws SessionNotFoundException;

	List<Session> getSessionByfollowUpOn(String followupOn)throws SessionNotFoundException;

	void autoArchiveSessions();

	List<Session> getSessions(String fromDate, String toDate, String dateType)throws SessionNotFoundException;

	List<Session> getBygroupName(String groupName);

	


	

}
