package com.maveric.csp.config;

import java.util.Collections;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.reactive.function.client.WebClient;

import com.maveric.csp.dtos.UserDTO;

public class CustomUserDetails  implements UserDetailsService{

	WebClient webClient;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

		UserDTO user = webClient.get()
                .uri("http://USER-SERVICE/api/v1/users/getby/" + email)
                .retrieve()
                .bodyToMono(UserDTO.class).block();

		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				Collections.emptyList());
	}
	
	
	

}
