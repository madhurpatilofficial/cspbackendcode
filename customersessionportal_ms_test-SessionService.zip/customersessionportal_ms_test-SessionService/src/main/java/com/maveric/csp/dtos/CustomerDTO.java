package com.maveric.csp.dtos;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CustomerDTO {

	    private Long customerId;
		
		private String customerName;
		
		private String customerEmail;
		
		@Enumerated(EnumType.STRING)
		private WealthMode wealthMode;
	 
		@Enumerated(EnumType.STRING)
		private PreferredInvestmentProduct preferredProduct;
		
		private String financialGoal;
}
