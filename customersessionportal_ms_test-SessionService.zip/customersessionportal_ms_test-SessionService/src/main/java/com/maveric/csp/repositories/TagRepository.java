package com.maveric.csp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.maveric.csp.entities.Tag;

@Repository
public interface TagRepository extends JpaRepository<Tag, Integer>{
	
	List<Tag> findByTagName(String tagName);
	List<Tag> findBySessionId(int i);
	
	@Query(value = "SELECT DISTINCT tag_name FROM tag;", nativeQuery = true)
	List<String> findAllTags();

}
