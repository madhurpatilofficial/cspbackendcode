package com.maveric.csp.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.common.net.HttpHeaders;
import com.maveric.csp.conversion.AppConversions;
import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.dtos.SessionCustomerDTO;
import com.maveric.csp.dtos.UserDTO;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.repositories.RemarkRepository;
import com.maveric.csp.repositories.SessionRepository;
import com.maveric.csp.repositories.TagRepository;

import jakarta.servlet.http.HttpServletRequest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.http.server.HttpServerRequest;

@Service
public class SessionServiceImpl implements SessionService {
	
	@Autowired
	HttpServletRequest request;

	@Autowired
	SessionRepository sessionRepository;
	
	@Autowired
	RemarkRepository remarkRepository;
	
	@Autowired
	TagRepository tagRepository;
	
	@Autowired
	WebClient webClient;
	
	
	@Override
	public Session createSession(Session sessionRequest, String username) throws SessionSaveException {

		CustomerDTO customer = webClient.get()
				.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + sessionRequest.getCustomerId()).retrieve()
				.bodyToMono(CustomerDTO.class).block();
		
		
		UserDTO user = webClient.get()
                .uri("http://USER-SERVICE/api/v1/users/getby/" + username)
                .retrieve()
                .bodyToMono(UserDTO.class).block();

		LocalDateTime currentDate = LocalDateTime.now();
		String formattedDate = AppConversions.convertDateToString(currentDate);

		sessionRequest.setCreatedOn(formattedDate);
		sessionRequest.setModifiedOn(formattedDate);
		sessionRequest.setIsActive("Yes");
		sessionRequest.setCreatedBy(user.getFirstName()+" "+user.getLastName());
		sessionRequest.setModifiedBy(user.getFirstName()+" "+user.getLastName());

		Session session = null;
		LocalDate currentLocalDate = LocalDate.now();

		if (sessionRequest.getFollowupOn() == null) {
			session = sessionRepository.save(sessionRequest);
		} else {
			LocalDate followupDate = AppConversions.convertStringToDate(sessionRequest.getFollowupOn());

			if (followupDate.isAfter(currentLocalDate)) {
				session = sessionRepository.save(sessionRequest);
			} else {
				throw new AllExceptions("Follow-up date is not in future");
			}
		}

		Remark remark = sessionRequest.getRemarks().get(0);
		remark.setSessionId(session.getSessionId());
		remark.setCreatedDate(formattedDate);
		remarkRepository.save(remark);

		Tag tag = sessionRequest.getTags().get(0);
		tag.setSessionId(session.getSessionId());
		tagRepository.save(tag);

		session.setCustomerDetails(customer);
		return session;
	}


	@Override
	public Session updateSession(Session session, String username) throws SessionNotFoundException {

		UserDTO user = webClient.get()
                .uri("http://USER-SERVICE/api/v1/users/getby/" + username)
                .retrieve()
                .bodyToMono(UserDTO.class).block();
		
			Session updatedSession = null;
			Optional<Session> databaseSession = sessionRepository.findById(session.getSessionId());

			LocalDateTime currentDate = LocalDateTime.now();
			String formatedDate = AppConversions.convertDateToString(currentDate);

			if (databaseSession.isPresent()) {
				Session dbSession = databaseSession.get();
				dbSession.setSessionName(session.getSessionName() == null ? dbSession.getSessionName() : session.getSessionName());
				dbSession.setCreatedOn(session.getCreatedOn() == null ? dbSession.getCreatedOn() : session.getCreatedOn());
				dbSession.setCustomerId(session.getCustomerId() == 0 ? dbSession.getCustomerId() : session.getCustomerId());
				dbSession.setFollowupOn(session.getFollowupOn() == null ? dbSession.getFollowupOn(): session.getFollowupOn()== ""? null : session.getFollowupOn());
				dbSession.setIsActive(session.getIsActive() == null ? dbSession.getIsActive() : session.getIsActive());
				dbSession.setPotentialLead(session.getPotentialLead() == null ? dbSession.getPotentialLead() : session.getPotentialLead());
				dbSession.setPriorityLevel(session.getPriorityLevel() == null ? dbSession.getPriorityLevel() : session.getPriorityLevel());
				dbSession.setModifiedOn(formatedDate);
				dbSession.setCreatedBy(session.getCreatedBy() == null ? dbSession.getCreatedBy() : session.getCreatedBy());
				dbSession.setModifiedBy(user.getFirstName()+" "+user.getLastName());
				
				if (session.getRemarks() != null) {

					Remark remark = session.getRemarks().get(0);
					remark.setCreatedDate(formatedDate);
					remark.setSessionId(dbSession.getSessionId());
					remarkRepository.save(remark);
				}

				if (session.getTags() != null) {
					Tag tag = session.getTags().get(0);
					tag.setSessionId(session.getSessionId());
					tagRepository.save(tag);
				}

				updatedSession = sessionRepository.save(dbSession);
				return updatedSession;
			} else {
				throw new SessionNotFoundException("session not found");
			}
		}

	@Override
	public Session makeArchiveSession(int sessionId) throws ArchiveSessionException, SessionNotFoundException {
		Optional<Session> foundSession = sessionRepository.findById(sessionId);
		Session archivedSession = null;
		
		if (foundSession.isPresent()) {
			Session session = foundSession.get();
			String followupOn = session.getFollowupOn();

			LocalDate followupDate = AppConversions.convertStringToDate(session.getFollowupOn());
			LocalDate currentDate = LocalDate.now();

			if (followupOn == null || !followupDate.isAfter(currentDate)) {
				session.setIsActive("No");
				archivedSession = sessionRepository.save(session);
			} else {

				throw new ArchiveSessionException("Follow-up date is in the future. Cannot archive the session.");
			}
		
		} else {
			
			throw new SessionNotFoundException("Session not found");
		}
		CustomerDTO customer = webClient.get()
				.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + +archivedSession.getCustomerId()).retrieve()
				.bodyToMono(CustomerDTO.class).block();
		List<Remark> remarksList = remarkRepository.findBySessionId(archivedSession.getSessionId());
		List<Tag> tagList = tagRepository.findBySessionId(sessionId);
		archivedSession.setRemarks(remarksList);
		archivedSession.setTags(tagList);
		archivedSession.setCustomerDetails(customer);
		return archivedSession;
	}

	@Override
	public List<Session> getActiveSessions(String username) throws SessionNotFoundException {
	    List<Session> activeSessionList = sessionRepository.findByIsActive("Yes");
	    List<Session> sessionList = new ArrayList<>();

	    System.out.println("username>>>"+username);
	    UserDTO user = webClient.get()
                .uri("http://USER-SERVICE/api/v1/users/getby/" + username)
                .retrieve()
                .bodyToMono(UserDTO.class).block();
	    
	    if (!activeSessionList.isEmpty()) {
	        for (Session session : activeSessionList) {
	        	String LoggedInuser = user.getFirstName() + " " + user.getLastName();
	        	if (LoggedInuser.equals(session.getCreatedBy())) {
	            CustomerDTO customer = webClient.get()
	                    .uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
	                    .retrieve()
	                    .bodyToMono(CustomerDTO.class).block();
	            
	            List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
	            List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());

	            session.setRemarks(remarksList);
	            session.setTags(tagList);
	            session.setCustomerDetails(customer);

	            sessionList.add(session);
	        }
	        }
	        return sessionList;
	    } else {
	        return Collections.emptyList();
	    }
	}


	@Override
	public List<Session> getArchivedSessions(String username) throws SessionNotFoundException {
		 List<Session> activeSessionList = sessionRepository.findByIsActive("No");
		    List<Session> sessionList = new ArrayList<>();
		    
		    System.out.println("username>>>"+username);
		    UserDTO user = webClient.get()
	                .uri("http://USER-SERVICE/api/v1/users/getby/" + username)
	                .retrieve()
	                .bodyToMono(UserDTO.class).block();

		    if (!activeSessionList.isEmpty()) {
		    	
		        for (Session session : activeSessionList) {
		        	String LoggedInuser = user.getFirstName() + " " + user.getLastName();
		        	if (LoggedInuser.equals(session.getCreatedBy())) {
		            CustomerDTO customer = webClient.get()
		                    .uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
		                    .retrieve()
		                    .bodyToMono(CustomerDTO.class).block();
		                   
		            List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
		            List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());

		            session.setRemarks(remarksList);
		            session.setTags(tagList);
		            session.setCustomerDetails(customer);

		            sessionList.add(session);
		        }
		        }
		        return sessionList;
		    } else {
		        return Collections.emptyList();
		    }
	}

	@Override
	public Session getSessionDetails(int sessionId) throws SessionNotFoundException {
		Optional<Session> databaseSession = sessionRepository.findBySessionId(sessionId);

		if (databaseSession.isPresent()) {

			Session foundSession = databaseSession.get();

			CustomerDTO customer = webClient.get()
                    .uri("http://CUSTOMER-SERVICE/api/v1/customers/" + foundSession.getCustomerId())
                    .retrieve()
                    .bodyToMono(CustomerDTO.class).block();
			
			List<Remark> remarksList = remarkRepository.findBySessionId(foundSession.getSessionId());
			List<Tag> tagList = tagRepository.findBySessionId(foundSession.getSessionId());
			foundSession.setRemarks(remarksList);
			foundSession.setCustomerDetails(customer);
			foundSession.setTags(tagList);

			return foundSession;
		} else {
			throw new SessionNotFoundException("Session not fount with Id:"+sessionId);
		}
	}

	@Override
	public List<Session> getSessionDetails(long customerID) throws SessionNotFoundException {
		List<Session> databaseSessionList = sessionRepository.findByCustomerId(customerID);

		if (databaseSessionList != null) {

			for (Session session : databaseSessionList) {
				CustomerDTO customer = webClient.get()
	                    .uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
	                    .retrieve()
	                    .bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return databaseSessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getSessionDetails(PotentialLead potentialLead) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.findByPotentialLead(potentialLead);

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}

	}


	@Override
	public List<Session> getSessionDetails(PriorityLevel priorityLevel) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.findByPriorityLevel(priorityLevel);
		 
		if (sessionList != null) {
 
			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
 
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
 	}
	
	@Override
	public List<Session> getSessionByCreatedOn(String createdOn) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.findByCreatedOn(createdOn);

		if (sessionList != null) {
			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getSessionByCreatedOn(String fromDate, String toDate) throws SessionNotFoundException {
		
		List<Session> sessionList = sessionRepository.getCreatedOnFromDateTodateSession(fromDate + " 00:00",toDate + " 23:59");

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getSessionByModifiedOn(String fromDate, String toDate) throws SessionNotFoundException {

		List<Session> sessionList = sessionRepository.getModifiedOnFromDateTodateSession(fromDate + " 00:00",toDate + " 23:59");
		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getSessionByModifiedOn(String modifiedOn) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.getSessionByModifiedOn(modifiedOn);


		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();			
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}

	}

	@Override
	public List<Session> getSessionByfollowUpOn(String followupOn) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.getSessionByFollowupOn(followupOn);
		if (sessionList != null) {
			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();		
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public void autoArchiveSessions() {
		List<Session> sessionsToArchive = sessionRepository.findByUpdatedDateBefore(LocalDate.now().minusDays(10));
		 for (Session session : sessionsToArchive) {
			 
			String followupOn = session.getFollowupOn();
			LocalDate followupDate = AppConversions.convertStringToDate(session.getFollowupOn());
			LocalDate currentDate = LocalDate.now();

			if (followupOn == null || !followupDate.isAfter(currentDate)) {
				session.setIsActive("No");
				 sessionRepository.save(session);
			} else {
				session.setIsActive("Yes");
				sessionRepository.save(session); 
			}
		} 
	}

	@Override
	public List<Session> getSessions(String fromDate, String toDate, String dateType) throws SessionNotFoundException {
	    try {
	        List<Session> sessionList = null;

	        switch (dateType) {
	            case "createdOn":
	                sessionList = sessionRepository.getCreatedOnFromDateTodateSession(fromDate + " 00:00", toDate + " 23:59");
	                break;
	            case "modifiedOn":
	                sessionList = sessionRepository.getModifiedOnFromDateTodateSession(fromDate + " 00:00", toDate + " 23:59");
	                break;
	            case "followupOn":
	                sessionList = sessionRepository.getFollowUpOnFromDateTodateSession(fromDate + " 00:00", toDate + " 23:59");
	                break;
	            default:
	                throw new IllegalArgumentException("Invalid dateType provided");
	        }

	        for (Session session : sessionList) {
	        	CustomerDTO customer = webClient.get()
						.uri("http://CUSTOMER-SERVICE/api/v1/customers/" + session.getCustomerId())
						.retrieve()
						.bodyToMono(CustomerDTO.class).block();

	            if (customer != null) {
	                List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
	                List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
	                session.setRemarks(remarksList);
	                session.setTags(tagList);
	                session.setCustomerDetails(customer);
	            }
	        }

	        return sessionList;
	    } catch (Exception e) {
	        throw new SessionNotFoundException("Error retrieving sessions within the specified date range: " + e.getMessage());
	    }	}


	@Override
	public List<Session> getBygroupName(String groupName) {

		return null;
	}

}
