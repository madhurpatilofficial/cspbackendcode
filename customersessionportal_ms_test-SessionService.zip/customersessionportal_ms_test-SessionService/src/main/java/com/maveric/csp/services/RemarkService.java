package com.maveric.csp.services;

import org.springframework.stereotype.Service;

import com.maveric.csp.entities.Remark;
import com.maveric.csp.exceptions.AllExceptions;

@Service
public interface RemarkService {

	Remark addRemark(Remark remark) throws AllExceptions;

}
